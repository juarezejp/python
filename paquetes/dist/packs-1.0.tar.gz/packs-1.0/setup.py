from setuptools import setup

setup(
    name="packs",
    version="1.0",
    description="Operaciones matematicas basicas",
    author="Eli",
    url="Eli.com",
    packages=["paquetes","paquetes.operacionesbasicas"]
    #rais, ruta
)

#python setup.py sdist 
#python3 setup.py sdist

